//
//  TchrViewController.swift
//  EEEinfo_1
//
//  Created by 石宇涵 on 2018/11/24.
//  Copyright © 2018 石宇涵. All rights reserved.
//

import UIKit
import Foundation


class TchrViewController: UIViewController,UIScrollViewDelegate  {
    
    @IBOutlet weak var BackClick: UIBarButtonItem!
    // @IBOutlet weak var jump: UIBarButtonItem!
    //  @IBOutlet var pageControl: UIPageControl!
   @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet var scrollView: UIScrollView!
    
    var courses = [
        ["name":"about","pic":"tchr5.png"],
        ["name":"study","pic":"tchr4.png"],
        ["name":"people","pic":"tchr3.png"],
        ["name":"research","pic":"tchr2.png"],
        ["name":"news","pic":"tchr1.png"],
        ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //设置scrollView的内容总尺寸
        scrollView.contentSize = CGSize(
            width: CGFloat(self.view.bounds.width) * CGFloat(self.courses.count),
            height: self.view.bounds.height
        )
        
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.scrollsToTop = false
        //协议代理，在本类中处理滚动事件
        scrollView.delegate = self
        //滚动时只能停留到某一页
        scrollView.isPagingEnabled = true
        //添加页面到滚动面板里
        
        let size = scrollView.bounds.size
        for (seq,course) in courses.enumerated() {
            let page = UIView()
            
            let imageView=UIImageView(image:UIImage(named:course["pic"]!))
            page.addSubview(imageView);
            page.backgroundColor = UIColor.green
            
            let lbl = UILabel(frame: CGRect(x:100 ,y: 100, width: 100, height: 20))
            
            //lbl.text = course["name"]
            page.addSubview(lbl)
            page.frame = CGRect(x: CGFloat(seq) * size.width, y: 0,
                                width: size.width, height: size.height)
            scrollView.addSubview(page)
        }
        
        //页控件属性
        pageControl.backgroundColor = UIColor.clear
        pageControl.numberOfPages = courses.count
        pageControl.currentPage = 0
        //设置页控件点击事件
        pageControl.addTarget(self, action: #selector(pageChanged(_:)),
                              for: UIControl.Event.valueChanged)
        
        //=======标题栏分页===============//
        //        let items=["电话","短信"] as [AnyObject]
        //        let segmented=UISegmentedControl(items:items)
        //        segmented.center=self.view.center
        //        segmented.selectedSegmentIndex=0 //默认选中第1项
        //        segmented.addTarget(self, action: Selector(("segmentDidchange:")),
        //                            for: UIControl.Event.valueChanged)  //添加值改变监听
        //        self.navigationItem.titleView = segmented
        //=======标题栏===============//
        
        //=======标题栏 移植===============//
        //设置title及title的颜色
        self.navigationItem.title = "Menu"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 16), NSAttributedString.Key.foregroundColor : UIColor.black]
        //设置导航栏颜色
        self.navigationController?.navigationBar.barTintColor = UIColor.black
        //设置navigation的titleView
        //        let image = UIImage(named: "logo0")
        //        let imageview = UIImageView(image: image)
        //        let titlebtn = UIButton.init(frame: CGRectMake(343 / 2 - 60, 32, 120, 12))
        //        titlebtn.addSubview(imageview)
        //        titlebtn.addTarget(self, action: #selector(MainViewController.refreshSelectedCluster), forControlEvents: UIControlEvents.TouchUpInside)
        //        self.navigationItem.titleView = titlebtn
        
        //导航栏-返回
        //        var backBtn = UIBarButtonItem.init(barButtonSystemItem:UIBarButtonItem.SystemItem.stop, target:self, action:#selector(getter: ViewController.BackClick))
        //        backBtn.tintColor = UIColor.white
        //        //backBtn = UIBarButtonItem(frame:CGRectMake(11.5,10,15,15))
        //       // backBtn.setImage(UIImage(named:"backbutton_x_normal"), forState:UIControlState.Normal)
        //        //backBtn.setImage(UIImage(named:"backbutton_x_highlight"), forState:UIControl.State.Highlighted)
        //        backBtn.addTarget(self, action:#selector(ViewController.BackClick), forControlEvents: .TouchUpInside)
        //        let left = UIBarButtonItem(customView: backBtn)
        
        //=======标题栏===============//
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //UIScrollViewDelegate方法，每次滚动结束后调用
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        //通过scrollView内容的偏移计算当前显示的是第几页
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        //设置pageController的当前页
        pageControl.currentPage = page
    }
    
    //点击页控件时事件处理
    @objc func pageChanged(_ sender:UIPageControl) {
        //根据点击的页数，计算scrollView需要显示的偏移量
        var frame = scrollView.frame
        frame.origin.x = frame.size.width * CGFloat(sender.currentPage)
        frame.origin.y = 0
        //展现当前页面内容
        scrollView.scrollRectToVisible(frame, animated:true)
    }
    
    func segmentDidchange(segmented:UISegmentedControl){
        //获得选项的索引
        print(segmented.selectedSegmentIndex)
        //获得选择的文字
        print(segmented.titleForSegment(at: segmented.selectedSegmentIndex))
    }
    
    
    
    
}




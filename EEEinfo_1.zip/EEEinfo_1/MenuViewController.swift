////
////  MenuViewController.swift
////  EEEinfo_1
////
////  Created by 石宇涵 on 2018/11/22.
////  Copyright © 2018 石宇涵. All rights reserved.
////
//
//
//import UIKit
//
//import SnapKit
//
//import ImagePicker
//
//import Lightbox
//
//import Alamofire
//
//import Foundation
//
//
//
//class imagePicker_collectionViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, ImagePickerDelegate {
//    
//    
//    
//    //-----------image array--------------------
//    
//    
//    
//    var imageCount : Int = 0
//    
//    var imageArray = Array<UIImage>()
//    
//    
//    
//    //------------collection view---------------
//    
//    
//    
//    let BJWidth = UIScreen.main.bounds.size.width
//    
//    let BJHeight = UIScreen.main.bounds.size.height
//    
//    var flowLayout:UICollectionViewFlowLayout!
//    
//    var myCollectionView: UICollectionView!
//    
//    
//    
//    //------------select button------------------------
//    
//    
//    
//    var button : UIButton! = UIButton()
//    
//    
//    
//    //------------save button----------------
//    
//    
//    
//    var saveBtn : UIButton! = UIButton()
//    
//    
//    
//    //------------------------------------------
//    
//    
//    
//    override func viewDidLoad() {
//        
//        super.viewDidLoad()
//        
//        
//        
//        //------------button------------------------
//        
//        
//        
//        button.setTitle("click", for: .normal)
//        
//        button.addTarget(self, action: #selector(buttonTouched(button:)), for: .touchUpInside)
//        
//        self.view.addSubview(button)
//        
//        button.snp.makeConstraints { (make) in
//            
//            make.width.equalTo(100)
//            
//            make.height.equalTo(50)
//            
//            make.centerX.equalTo(self.view.snp.centerX)
//            
//            make.top.equalTo(self.view.snp.top).offset(100)
//            
//        }
//        
//        
//        
//        //------------save button----------------
//        
//        
//        
//        saveBtn.setTitle("save", for: .normal)
//        
//        saveBtn.addTarget(self, action: #selector(upload), for: .touchUpInside)
//        
//        self.view.addSubview(saveBtn)
//        
//        saveBtn.snp.makeConstraints { (make) in
//            
//            make.width.equalTo(100)
//            
//            make.height.equalTo(50)
//            
//            make.centerX.equalTo(self.view.snp.centerX)
//            
//            make.top.equalTo(self.button.snp.bottom).offset(500)
//            
//        }
//        
//        
//        
//        //------------collection view---------------
//        
//        
//        
//        flowLayout = UICollectionViewFlowLayout()
//        
//        myCollectionView = UICollectionView.init(frame: view.bounds, collectionViewLayout: flowLayout)
//        
//        myCollectionView.delegate = self
//        
//        myCollectionView.backgroundColor = UIColor(displayP3Red: 54/255, green: 45/255, blue: 66/255, alpha: 1)
//        
//        myCollectionView.dataSource = self
//        
//        myCollectionView.register(UINib(nibName:"NormalCell", bundle: nil), forCellWithReuseIdentifier:"Normal")
//        
//        myCollectionView.collectionViewLayout = flowLayout
//        
//        flowLayout = UICollectionViewFlowLayout.init()
//        
//        flowLayout.itemSize = CGSize(width:(BJWidth-30)/2 , height:(BJWidth-30)/2 )
//        
//        self.view.addSubview(myCollectionView)
//        
//        myCollectionView.snp.makeConstraints { (make) in
//            
//            make.width.equalTo(self.view.snp.width).multipliedBy(0.9)
//            
//            make.height.equalTo(300)
//            
//            make.centerX.equalTo(self.view.snp.centerX)
//            
//            make.top.equalTo(button.snp.bottom).offset(100)
//            
//        }
//        
//        
//        
//        //------------------------------------------
//        
//        
//        
//    }
//    
//    
//    
//    // MARK: - ImagePickerDelegate
//    
//    func cancelButtonDidPress(_ imagePicker: ImagePickerController) {
//        
//        imagePicker.dismiss(animated: true, completion: nil)
//        
//    }
//    
//    
//    
//    func wrapperDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
//        
//        guard images.count > 0 else { return }
//        
//        let lightboxImages = images.map {
//            
//            return LightboxImage(image: $0)
//            
//        }
//        
//        
//        
//        let lightbox = LightboxController(images: lightboxImages, startIndex: 0)
//        
//        imagePicker.present(lightbox, animated: true, completion: nil)
//        
//    }
//    
//    
//    
//    func doneButtonDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
//        
//        
//        
//        var imageAssets: [UIImage] {
//            
//            return AssetManager.resolveAssets(imagePicker.stack.assets)
//            
//        }
//        
//        let imageSegue = imageAssets
//        
//        print("一共选择了\(imageSegue.count)张图片,")
//        
//        self.imageCount = imageSegue.count
//        
//        self.imageArray = imageAssets
//        
//        imagePicker.dismiss(animated: true, completion: nil)
//        
//        self.myCollectionView.reloadData()
//        
//    }
//    
//    
//    
//    //添加图片按钮点击方法
//    
//    @objc func buttonTouched(button: UIButton) {
//        
//        var config = Configuration()
//        
//        config.doneButtonTitle = "Finish"
//        
//        config.noImagesTitle = "Sorry! There are no images here!"
//        
//        config.recordLocation = false
//        
//        config.allowVideoSelection = true
//        
//        let imagePicker = ImagePickerController(configuration: config)
//        
//        imagePicker.delegate = self
//        
//        present(imagePicker, animated: true, completion: nil)
//        
//    }
//    
//    
//    
//    
//    
//    //照片上传
//    
//    @objc func upload()
//        
//    {
//        
//        
//        
//    }
//    
//    
//    
//    
//    
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        
//        return imageCount;
//        
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"Normal", for:indexPath) as! NormalCell
//        
//        cell.collectionImage.image = imageArray[indexPath.row]
//        
//        return cell
//        
//    }
//    
//    
//    
//    override func didReceiveMemoryWarning() {
//        
//        super.didReceiveMemoryWarning()
//        
//        // Dispose of any resources that can be recreated.
//        
//    }
//    
//    
//    
//}
//
//

